import checker as cK
import createFile as cF
import os

timeLimit = 1.0 #set time

cK.Checker(cF.createExe(), timeLimit)