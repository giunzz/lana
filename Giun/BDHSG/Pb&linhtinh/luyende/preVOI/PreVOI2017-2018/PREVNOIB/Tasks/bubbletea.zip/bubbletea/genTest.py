#!/usr/bin/python

import os

TREE_TYPES = ["SHORT", "LONG", "MIXED"]
COST_TYPES = ["NORMAL", "SPECIAL"]
PAIR_TYPES = ["LIGHT", "MEDIUM", "DENSE", "MINIMUM", "MAXIMUM"]

def genSmallTest(sub, numTest, pair):
    for i in range(numTest):
        tree = TREE_TYPES[i % 3]
        cost = COST_TYPES[i % 2]
        testName = "%s_%d_%s_%s.in" % (sub, i + 1, tree, cost)
        print "Running %s" % (testName)
        run = os.system("./gen %s %s %s > %s" % (tree, cost, pair, testName))
        if run != 0:
            print "FAILED %s" % (testName)
            exit(1)
        validate = os.system("./validator < %s" % (testName))
        if validate != 0:
            print "FAILED %s" % (testName)
        os.system("sleep 2s")

def genLargeTest():
    testCount = 0
    for tree in TREE_TYPES:
        for cost in COST_TYPES:
            for pair in PAIR_TYPES[0:3]:
                for i in range(2):
                    testCount += 1
                    testName = "C_%d_%s_%s_%s.in" % (testCount, tree, cost, pair)
                    print "Running %s" % (testName)
                    run = os.system("./gen %s %s %s > %s" % (tree, cost, pair, testName))
                    if run != 0:
                       print "FAILED %s" % (testName)
                       exit(1)
                    validate = os.system("./validator < %s" % (testName))
                    os.system("sleep 2s")

genSmallTest("A", 18, "MINIMUM")
genSmallTest("B", 14, "MAXIMUM")
genLargeTest()
