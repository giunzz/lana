#include<bits/stdc++.h>
#define FOR(i,a,b) for (int i=(a),_b=(b);i<=_b;i=i+1)
#define FORD(i,b,a) for (int i=(b),_a=(a);i>=_a;i=i-1)
#define REP(i,n) for (int i=0,_n=(n);i<_n;i=i+1)
#define FORE(i,v) for (__typeof((v).begin()) i=(v).begin();i!=(v).end();i++)
#define ALL(v) (v).begin(),(v).end()
#define fi   first
#define se   second
#define MASK(i) (1LL<<(i))
#define BIT(x,i) (((x)>>(i))&1)
#define div   ___div
#define next   ___next
#define prev   ___prev
#define left   ___left
#define right   ___right
#define __builtin_popcount __builtin_popcountll
using namespace std;
template<class X,class Y>
    void minimize(X &x,const Y &y) {
        if (x>y) x=y;
    }
template<class X,class Y>
    void maximize(X &x,const Y &y) {
        if (x<y) x=y;
    }
template<class T>
    T Abs(const T &x) {
        return (x<0?-x:x);
    }

/* Author: Van Hanh Pham */

/** END OF TEMPLATE - ACTUAL SOLUTION COMES HERE **/

int randInt(int l, int r) {
    assert(l <= r);
    return l + rand() % (r - l + 1);
}

int getSpecialRandom(void) {
    double tmp = 30.0 * randInt(0, MASK(30)) / MASK(30);
    return pow(2, tmp);
}

int randSpecialInt(int l, int r) {
    assert(l <= r);
    return l + getSpecialRandom() % (r - l + 1);
}

const string TREE_TYPES[] = {"SHORT", "LONG", "MIXED"};
const string COST_TYPES[] = {"NORMAL", "SPECIAL"};
const string PAIR_TYPES[] = {"LIGHT", "MEDIUM", "DENSE", "MINIMUM", "MAXIMUM"};
const int MAX_N = (int)5e4;
const int MAX_C = (int)1e9;

string treeType, costType, pairType;
int numNode, numPair;

void check(void) {
    bool ok = false;
    REP(i, 3) if (treeType == TREE_TYPES[i]) ok = true;
    assert(ok);

    ok = false;
    REP(i, 2) if (costType == COST_TYPES[i]) ok = true;
    assert(ok);

    ok = false;
    REP(i, 5) if (pairType == PAIR_TYPES[i]) ok = true;
    assert(ok);
}

void init(void) {
    numNode = randInt(MAX_N / 3, MAX_N);
    if (pairType == PAIR_TYPES[0]) numPair = 2 * randInt(50, 100);
    else if (pairType == PAIR_TYPES[1]) numPair = 2 * randInt(250, 750);
    else if (pairType == PAIR_TYPES[2]) numPair = 2 * randInt(numNode / 10, numNode / 2);
    else if (pairType == PAIR_TYPES[3]) numPair = 2 * randInt(1, 5);
    else if (pairType == PAIR_TYPES[4]) {
        numNode -= numNode % 2;
        numPair = numNode;
    }
    else assert(false);
}

int par[MAX_N + 5], lab[MAX_N + 5];
vector<pair<int, int>> genTree(void) {
    FOR(i, 1, numNode) lab[i] = i;
    random_shuffle(lab + 1, lab + numNode + 1);

    if (treeType == TREE_TYPES[0]) {
        FOR(i, 2, numNode) par[i] = randInt(1, i - 1);
    } else if (treeType == TREE_TYPES[1]) {
        FOR(i, 2, numNode) par[i] = randInt(max(1, i - 7), i - 1);
    } else {
        FOR(i, 2, numNode / 3) par[i] = i - 1;
        FOR(i, numNode / 3 + 1, 2 * numNode / 3) par[i] = randInt(1, 3);
        FOR(i, 2 * numNode / 3 + 1, numNode) par[i] = randInt(1, i - 1);
    }

    vector<pair<int, int>> res;
    FOR(i, 2, numNode) {
        int u = lab[i];
        int v = lab[par[i]];
        if (rand() % 2) swap(u, v);
        res.push_back(make_pair(u, v));
    }
    return res;
}

vector<int> genNode(void) {
    vector<int> nodes;
    FOR(i, 1, numNode) nodes.push_back(i);
    random_shuffle(ALL(nodes));
    nodes.resize(numPair);
    return nodes;
}

vector<int> genCost(void) {
    vector<int> res;
    REP(love, numNode - 1) res.push_back(costType == COST_TYPES[0] ? randInt(1, MAX_C) : randSpecialInt(1, MAX_C));
    return res;
}

void process(void) {
    vector<pair<int, int>> edges = genTree();
    vector<int> nodes = genNode();
    vector<int> cost = genCost();

    random_shuffle(ALL(edges));
    random_shuffle(ALL(nodes));
    random_shuffle(ALL(cost));

    printf("%d %d\n", numNode, numPair);
    FORE(it, nodes) printf("%d ", *it); printf("\n");
    REP(i, numNode - 1) printf("%d %d %d\n", edges[i].fi, edges[i].se, cost[i]);
}

int main(int argc, char* argv[]) {
    srand(time(NULL));

    treeType = argv[1] == NULL ? TREE_TYPES[0] : string(argv[1]);
    costType = argv[2] == NULL ? COST_TYPES[0] : string(argv[2]);
    pairType = argv[3] == NULL ? PAIR_TYPES[0] : string(argv[3]);

    check();
    init();
    process();
    return 0;
}

/*** LOOK AT MY CODE. MY CODE IS AMAZING :D ***/
